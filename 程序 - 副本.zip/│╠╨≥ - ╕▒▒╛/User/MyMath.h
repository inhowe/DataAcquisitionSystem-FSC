#ifndef __MYMATH_H
#define __MYMATH_H

#include "includes.h"
u16 AveWeightedRecurFilt(u16  *array,u8	list) ;
u16 Average (u16 *array,u8	list);
#endif
