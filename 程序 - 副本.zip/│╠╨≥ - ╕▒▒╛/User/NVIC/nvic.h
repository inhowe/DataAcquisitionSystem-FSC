#ifndef __NVIC_H
#define __NVIC_H

#include "includes.h"
void NVIC_Config(void);

#endif
