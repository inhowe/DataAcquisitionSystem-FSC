#ifndef __CAN_H
#define __CAN_H

#include "includes.h"
void CAN_Config(void);

#endif
