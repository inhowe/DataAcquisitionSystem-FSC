#ifndef __EXTI_H
#define __EXTI_H

#include "stm32f10x_lib.h"
#include "stdio.h"
void  EXTI_Configuration(void);
//void EXTI0_IRQHandler(void);


#endif
