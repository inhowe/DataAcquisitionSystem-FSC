#ifndef __PWM_OUTPUT_H
#define	__PWM_OUTPUT_H

#include "includes.h"

void PWM_TIM2_Config(void);

#endif /* __PWM_OUTPUT_H */

