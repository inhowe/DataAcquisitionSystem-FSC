#ifndef __CAPTURE_H
#define __CAPTURE_H

#include "includes.h"

void TIM3_Cap_Init(u16 arr,u16 psc);
void TIM4_Cap_Init(u16 arr,u16 psc);

#endif
